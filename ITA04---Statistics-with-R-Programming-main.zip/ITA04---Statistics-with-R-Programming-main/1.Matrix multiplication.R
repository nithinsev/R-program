matE <- matrix(0, nrow = 3, ncol = 3)
print(matE)
