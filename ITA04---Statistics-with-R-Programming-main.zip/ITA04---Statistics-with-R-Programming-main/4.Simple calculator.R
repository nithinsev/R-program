add <- function(a, b) {
  return(a + b)
}

# Function for subtraction
subtract <- function(a, b) {
  return(a - b)
}

# Function for multiplication
multiply <- function(a, b) {
  return(a * b)
}

# Function for division
divide <- function(a, b) {
  return(a / b)
}

# Example usage
result_add <- add(5, 3)
result_subtract <- subtract(10, 4)
result_multiply <- multiply(2, 6)
result_divide <- divide(10, 2)

# Printing the results
print(result_add)
print(result_subtract)
print(result_multiply)
print(result_divide)
