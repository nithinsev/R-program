data <- read.csv("stu.csv")
print("CSV File Content:")
print(data)