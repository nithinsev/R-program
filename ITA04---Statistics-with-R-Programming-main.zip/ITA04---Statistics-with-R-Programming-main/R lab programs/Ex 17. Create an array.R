values <- c(1, 2, 3, 4, 5, 6)
dims <- c(2, 3)
my_array <- array(values, dim = dims, dimnames = list(c("row1", "row2"), c("col1", "col2", "col3")))
my_array
