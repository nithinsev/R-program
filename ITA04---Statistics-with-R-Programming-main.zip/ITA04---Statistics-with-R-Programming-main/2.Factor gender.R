gender <- factor(c("male", "female", "female", "male"))

# Checking if the variable is a factor
is_factor <- is.factor(gender)

# Printing the result
print(is_factor)
