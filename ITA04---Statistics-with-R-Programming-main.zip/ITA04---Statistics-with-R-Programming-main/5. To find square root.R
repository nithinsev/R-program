result_sqrt <- sqrt(729)
print(result_sqrt)
